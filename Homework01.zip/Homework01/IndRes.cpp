#include "stdafx.h"
#include "IndRes.h"

CIndRes::CIndRes()
{
}

CIndRes::~CIndRes()
{
}
