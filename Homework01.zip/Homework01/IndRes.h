#pragma once
class CIndRes
{
public:
	CIndRes();
	~CIndRes();

};

